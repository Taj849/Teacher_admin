@extends('layouts.teacher')
@section('body')

<!--outter-wp-->
<div class="outter-wp">
    <!--sub-heard-part-->
      <div class="sub-heard-part">
       <ol class="breadcrumb m-b-0">
            <li><a href="index.html">Home</a></li>
            <li class="active">Tables</li>
        </ol>
       </div>
  <!--//sub-heard-part-->
    <div class="graph-visual tables-main">
      
      <p style="float: right">
        <a class="a_demo_three" href="#">
          Active!
        </a>
      </p>
      
            <h2 class="inner-tittle">Total {{$course_code}} Mark</h2>
                <div class="graph">
                        <div class="tables">
                                
                                <table class="table">
                                    <thead>
                                        <tr>
                                          <th>Student Id</th>
                                          <th>Course Code</th>
                                          <th>ClassTest Mark</th>
                                          <th>Viva Mark</th>
                                          <th>Presentation Mark</th>
                                           <th>Total Mark</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        @foreach($data_merge as $data)
                                        <tr>
                                            @php
                                                $sum=0;
                                            @endphp
                                            <td>{{$data}}</td>
                                            <td>{{$course_code}}</td>
                                        @for($b=0;$b<$e;$b++)
                                            @if($data==$student_data[$b])
                                            
                                            @php
                                                $class_mark=$total_mark[$b];
                                                $sum=$sum+$total_mark[$b];
                                            @endphp
                                            @endif
                                        @endfor
                                        @if ($class_mark)
                                        <td>{{$class_mark}}</td>
                                        @php
                                            $class_mark=0;
                                        @endphp
                                        @else
                                            <td></td>
                                        @endif
                                        @for($b=0;$b<$q;$b++)
                                            @if($data==$vstudent_data[$b])
                                            
                                            @php
                                               $viva_mark= $vtotal_mark[$b];
                                                $sum=$sum+$vtotal_mark[$b];
                                            @endphp
                                            @endif
                                        @endfor
                                        @if ($viva_mark)
                                        <td>{{$viva_mark}}</td>
                                        @php
                                            $viva_mark=0;
                                        @endphp
                                        @else
                                        <td></td>
                                        @endif
                                        @for($b=0;$b<$n;$b++)
                                        
                                            @if($data==$pstudent_data[$b])
                                            
                                            @php
                                            $presentation_mark=$ptotal_mark[$b];
                                            $sum=$sum+$ptotal_mark[$b];
                                            @endphp
                                            @endif
                                        @endfor
                                        @if ($presentation_mark)
                                        <td>{{$presentation_mark}}</td>
                                        @php
                                            $presentation_mark=0;
                                        @endphp
                                        @else
                                            <td></td>
                                        @endif
                                        <td>{{$sum}}</td> 
                                        </tr>   
                                        @endforeach
                                    </tbody>
                                </table>
                                
                            </div>
                </div>
        </div>
        <!--//graph-visual-->
    </div>
    <!--//outer-wp-->
    
@endsection