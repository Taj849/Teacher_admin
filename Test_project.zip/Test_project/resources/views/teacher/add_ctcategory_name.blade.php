@extends('layouts.teacher')
@section('body')

<!--outter-wp-->
<div class="outter-wp">
    <!--sub-heard-part-->
      <div class="sub-heard-part">
       <ol class="breadcrumb m-b-0">
            <li><a href="index.html">Home</a></li>
            <li class="active">Tables</li>
        </ol>
       </div>
  <!--//sub-heard-part-->
  <!--/forms-->
  <div class="forms-main">
    <h2 class="inner-tittle">Add {{session('classtest_names')}} Category Name</h2>
        <div class="graph-form">
                <div class="validation-form">
                            <!---->
                                
                <form action="{{url('addpCtname')}} " method="post">
                                    @csrf
                                    <div class="vali-form">
                                          <div class="clearfix"> </div>
                                          <div class="col-md-6 form-group1 form-last">
                                            <label class="control-label"> Now Add Category</label>
                                            
                                          </div>
                                        @for ($i = 0; $i < $count; $i++)
                                        <div class="clearfix"> </div>
                                        <div class="col-md-6 form-group1 form-last">
                                            
                                        <input type="text"  name="name[]" required="">   
                                        </div>
                                        @endfor
                                    
                                    <div class="clearfix"> </div>
                                    <div class="col-md-12 form-group button-2">
                                      <button type="submit" class="btn btn-primary">Save</button>
                                      
                                    </div>
                                  <div class="clearfix"> </div>
                                </form>
                            
                            <!---->
                         </div>

                    </div>
            </div> 
    <!--//forms-->											   
</div>
<!--//outer-wp-->
    
    
@endsection