@extends('layouts.teacher')
@section('body')

<!--outter-wp-->
<div class="outter-wp">
    <!--sub-heard-part-->
      <div class="sub-heard-part">
       <ol class="breadcrumb m-b-0">
            <li><a href="index.html">Home</a></li>
            <li class="active">Tables</li>
        </ol>
       </div>
  <!--//sub-heard-part-->
  <!--/forms-->
  <div class="forms-main">
    <h2 class="inner-tittle">Add ClassTest Name</h2>
        <div class="graph-form">
                <div class="validation-form">
                    <div>


                        <form action="{{url('addCcategoryname')}}" method="post" >
                            @csrf
                        @foreach ($class_name as $item)
                        <div class="vali-form">
                            <div class="col-md-6 form-group1">
                              <label class="control-label">ClassTest Name</label>
                              <input type="text" value="{{$item->classtest_name}}" name="ct_name" required="">
                            </div>
                            <div class="col-md-6 form-group1 form-last">
                              <label class="control-label">Course Code</label>
                              <input type="text" value="{{$item->course_code}}" name="c_code" required="">
                            </div>
                            <div class="clearfix"> </div>
                                <div class="col-md-6 form-group1 form-last">
                                <label class="control-label"><strong>How many category want to add</strong>  </label>
                                <input type="text" placeholder="Category No"  required="" name="count">   
                            </div>
                            <div class="clearfix"> </div>
                            <div class="col-md-12 form-group button-2">
                              <button  class="btn btn-primary" type="submit">Add Name</button> 
                            </div>
                          </div>
                          <div class="clearfix"> </div>
                        @endforeach    
                        
                        
                        </form>
                        </div>
                         </div>

                    </div>
            </div> 
    <!--//forms-->											   
</div>
<!--//outer-wp-->
    
    
@endsection