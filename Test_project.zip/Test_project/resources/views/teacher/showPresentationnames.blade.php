@extends('layouts.teacher')
@section('body')

<!--outter-wp-->
<div class="outter-wp">
    <!--sub-heard-part-->
      <div class="sub-heard-part">
       <ol class="breadcrumb m-b-0">
            <li><a href="index.html">Home</a></li>
            <li class="active">Tables</li>
        </ol>
       </div>
  <!--//sub-heard-part-->
  <div class="col-md-6 " style="margin-bottom: 20px">
    <h3 class="sub-tittle">Presentation Name </h3>
    
     

    @foreach (session('pre_name') as $item)
    
    
       <ul class="timeline">
           <li>
             <div class="timeline-badge success"><i class="fa fa-check-circle-o"></i></div>
             <div class="timeline-panel">
              
               <div class="timeline-heading">
               <h4 class="timeline-title"><a href="addptestmark/{{$item->id}}">{{$item->presentation_name}}</a>   </h4>

               <div class="timeline-action">
                <a  href="index.html" class="tooltips"><span>Edit</span><i class="fa fa-edit" style='font-size:15px;'></i></a>
                <a  href="/deletePrename/{{$item->id}}"onclick="return confirm('Are you sure you want to delete this item?');" class="tooltips"><span>Delete</span><i class="fa fa-trash-o" style='font-size:15px;'></i></a>

               </div>
               
               
               </div>

             </div>
           </li>
       </ul>
       @endforeach 
       
       <div style="margin-bottom: 10px;text-align:center">
        {{ $pre_name->links() }} 
       </div>
   </div>
   
   
   <div class="col-md-6 ">
    <p class="four">
        <a class="a_demo_four" href="{{url('addP_test_name')}}">
            Add New Presentation !
        </a>
     </p>
       
   </div>
   
  
    <!--//outer-wp-->
  
    
@endsection