@extends('layouts.teacher')
@section('body')

<!--outter-wp-->
<div class="outter-wp">
    <!--sub-heard-part-->
      <div class="sub-heard-part">
       <ol class="breadcrumb m-b-0">
            <li><a href="index.html">Home</a></li>
            <li class="active">Tables</li>
        </ol>
       </div>
  <!--//sub-heard-part-->
  <!--/forms-->
  <div class="forms-main">
    
    <h2 class="inner-tittle">Update {{$vname}}  Mark</h2>
        <div class="graph-form">
                <div class="validation-form">
                            <!---->
                                
                <form action="/editCtestmark/{{$value[0]->student_id}}/{{$value[0]->course_code}} " method="post">
                                    @csrf
                                    <div class="vali-form">
                                      <div class="col-md-6 form-group1">
                                        <label class="control-label">ClassTest name</label>
                                        <input type="text" value="{{$vname}}" name="viva_name" required="">
                                      </div>
                                      <div class="col-md-6 form-group1 form-last">
                                        <label class="control-label">Course Code</label>
                                        <input type="text" value="{{$value[0]->course_code}}" name="c_code" required="">
                                      </div>   
                                     
                                        <div class="col-md-6 form-group1">
                                            <label class="control-label">Student Id</label>
                                            <input type="text" value="{{$value[0]->student_id}}" name="s_id" required="">
                                          </div>
                                          <div class="clearfix"> </div>
                                          @foreach ($class_name as $item)
                                          <div class="col-md-6 form-group1">
                                            <label class="control-label">{{$item->category_name}}</label>
                                           @for ($i = $sid; $i < $count; $i++)
                                           <input type="text" value="{{$value[$i]->classtest_marks}}" name="mark[]" required="">
                                           @php
                                               $sid++;
                                          break;
                                           @endphp
                                           @endfor
                                            
                                          </div>
                                          <div class="clearfix"> </div>
                                          @endforeach    
                                    <div class="clearfix"> </div>
                                    <div class="col-md-12 form-group button-2">
                                      <button type="submit" onclick="return confirm('Are you sure you want to Update this item?');" class="btn btn-primary">Save</button>
                                      
                                    </div>
                                  <div class="clearfix"> </div>
                                </form>
                            
                            <!---->
                         </div>

                    </div>
            </div> 
    <!--//forms-->											   
</div>
<!--//outer-wp-->
    
    
@endsection