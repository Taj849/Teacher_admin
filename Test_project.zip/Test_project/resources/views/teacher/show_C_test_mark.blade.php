@extends('layouts.teacher')
@section('body')

<!--outter-wp-->
<div class="outter-wp">
    <!--sub-heard-part-->
      <div class="sub-heard-part">
       <ol class="breadcrumb m-b-0">
            <li><a href="index.html">Home</a></li>
            <li class="active">Tables</li>
        </ol>
       </div>
  <!--//sub-heard-part-->
    <div class="graph-visual tables-main">
      
      <p style="float: right">
        <a class="a_demo_three" href="#">
          Active!
        </a>
      </p>
      
            <h2 class="inner-tittle">ClassTest Mark</h2>
            @if (session('delete'))
                            <div class="alert alert-success">
                              {{ session('delete') }}
                            </div>
                          @endif
                          @if (session('update'))
                          <div class="alert alert-success">
                            {{ session('update') }}
                          </div>
                        @endif
                <div class="graph">
                        <div class="tables">
                                @if ($count)
                                <table class="table">
                                    <thead>
                                        <tr>
                                          <th>Student Id</th>
                                          <th>Course Code</th>
                                        @foreach ($class_name as $item)
                                            <th>{{$item->category_name}}</th>  
                                        @endforeach
                                           <th>Action</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        @php
                                            $mark=0;
                                        @endphp
                                        @for ($j=0;$j<$s_count/$count;$j++)
                                        <tr>
                                         
                                        @for ($i=0;$i<$count;$i++)
                                          @if ($mark!=$datam[$j][$i]->student_id)
                                          <td>{{$datam[$j][$i]->student_id}}</td>
                                          <td>{{$datam[$j][$i]->course_code}}</td>
                                          @endif
                                            @php
                                                $mark=$datam[$j][$i]->student_id;
                                            @endphp
                                                
                                                <td>{{$datam[$j][$i]->classtest_marks}}</td>
                                        @endfor
                                                
                                                <td>
                                                <a  href="/updateCtestmark/{{$datam[$j][$i-1]->student_id}}/{{$datam[$j][$i-1]->course_code}}" class="tooltips"><span>Edit</span><i class="fa fa-edit" style='font-size:24px;padding-raight:10px;'></i></a>
                                                <a  href="/deleteCtestmark/{{$datam[$j][$i-1]->student_id}}/{{$datam[$j][$i-1]->course_code}}"class="tooltips" onclick="return confirm('Are you sure you want to delete this item?');">
                                                  <span>Delete</span>
                                                  <i class="fa fa-trash-o" style='font-size:24px; padding-left:10px;'></i>
                                                </a>
                                                  </td>
                                                        
                                        </tr>
                                        @endfor 
                                        
                                            
                                    </tbody>
                                </table>
                                @endif
                            </div>
                </div>
        </div>
        <!--//graph-visual-->
    </div>
    <!--//outer-wp-->
    
@endsection