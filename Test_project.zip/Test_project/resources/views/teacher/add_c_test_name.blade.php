@extends('layouts.teacher')
@section('body')

<!--outter-wp-->
<div class="outter-wp">
    <!--sub-heard-part-->
      <div class="sub-heard-part">
       <ol class="breadcrumb m-b-0">
            <li><a href="index.html">Home</a></li>
            <li class="active">Tables</li>
        </ol>
       </div>
  <!--//sub-heard-part-->
  <!--/forms-->
  <div class="forms-main">
    <h2 class="inner-tittle">Add ClassTest Name</h2>
        <div class="graph-form">
                <div class="validation-form">
                    <div>
                      @if (session()->has('add'))
                            <div class="alert alert-danger">
                              {{ session('add') }}
                            </div>
                          @endif

                        <form action="{{url('addccategoryname')}}" method="post" >
                            @csrf
                            
                        <div class="vali-form">
                            <div class="col-md-6 form-group1">
                              <label class="control-label">ClassTest Name</label>
                              <input type="text" placeholder="ClassTest name" name="ct_name" required="">
                            </div>
                            <div class="col-md-6 form-group1 form-last">
                              <label class="control-label">Course Code</label>
                              <input type="text" placeholder="Course Code" name="c_code" required="">
                            </div>
                            <div class="clearfix"> </div>
                                <div class="col-md-6 form-group1 form-last">
                                <label class="control-label"><strong>How many category want to add</strong>  </label>
                                <input type="text" placeholder="Category No"  required="" name="count">   
                            </div>
                            <div class="clearfix"> </div>
                            <div class="col-md-12 form-group button-2">
                              <button  class="btn btn-primary" type="submit">Add Name</button> 
                            </div>
                          </div>
                          <div class="clearfix"> </div>
                        
                        </form>
                        </div>
                         </div>

                    </div>
            </div> 
    <!--//forms-->											   
</div>
<!--//outer-wp-->
    
    
@endsection