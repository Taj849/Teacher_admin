<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class ClassTestController extends Controller
{
    public function showCname()
    {
        
        $ctest_name = DB::table('classtests')->where('teacher_id','abc123')
        ->paginate(4);
        session()->put('ctest_name',$ctest_name);
        return view('teacher/showClasstestnames',compact('ctest_name'));

    }

    public function addctname(Request $request)
    {
        $c_code=0;
        $ctest_course_code = DB::table('classtests')
        ->where('teacher_id','abc123')
        ->where('course_code',$request->c_code)
        ->select('course_code')
        ->get();
        foreach($ctest_course_code as $course_code)
        {
            $c_code=$course_code->course_code;
        }
        if($c_code)
        {
            $request->session()->flash('add', 'Course Code Already exsits! ');
            return view('teacher/add_c_test_name');
        }else{
            DB::beginTransaction();
        try {
            $viva_name=array();
        $viva_name['teacher_id'] = 'abc123';
        $viva_name['classtest_name'] = $request->ct_name;
        $viva_name['course_code'] = $request->c_code;
        DB::table('classtests')->insert($viva_name);
        $classtest_names = $request->ct_name;
        $request->session()->put('classtest_names',$classtest_names);
        $count=$request->count;
            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
        }
        return view('teacher/add_ctcategory_name',compact('classtest_names','count'));
        }
        
    }
    public function addCtcname(Request $request)
    {
        $viva_id=DB::table('classtests')
        ->where('classtest_name',session('classtest_names'))
        ->select('id')
        ->get();
        
        $test=array();
        
        foreach($request->get('name') as $name) {
            $test['classtest_id'] =$viva_id[0]->id;
            $test['category_name']=$name;
            DB::table('classtestcategories')->insert($test);
        }
        return redirect()->to('addC_test_mark');
        

    }
    public function addCtestmark(Request $req,$id )
    {
        $cls_name=0;
        $class_name = DB::table('classtests')
        ->join('classtestcategories', 'classtestcategories.classtest_id', '=', 'classtests.id')
        ->where('classtests.id','=',$id)
        ->select('classtests.classtest_name','classtests.course_code','classtestcategories.category_name','classtestcategories.id')
        ->get();
        
        foreach($class_name as $data)
        {
            $cls_name=$data->classtest_name;
            $c_code=$data->course_code;
        }
        if($cls_name)
        {
            $req->session()->put('class_name',$class_name);
            $req->session()->put('cls_name',$cls_name);
            $req->session()->put('c_code',$c_code);
            return view('teacher/c_mark_add',compact('class_name','cls_name','c_code'));
        }else{
            $class_name = DB::table('classtests')
        ->where('classtests.id','=',$id)
        ->select('classtests.classtest_name','classtests.course_code','classtests.teacher_id')
        ->get();
            return view('teacher/add_cC_category',compact('class_name'));
        }
         

    }
    public function addcCtname(Request $request)
    {
        $classtest_names = $request->ct_name;
        session()->put('classtest_names',$classtest_names);
        $c_code=$request->c_code;
        $count=$request->count;
        return view('teacher/add_ctcategory_name',compact('classtest_names','count','c_code'));
    }

    public function addCmark(Request $request)
    {
        
        $stu_data=0;
        $student_id=$request->s_id;
        $course_code=session()->get('c_code');
        
        $student_data = DB::table('classtestmarks')
        ->where('classtestmarks.student_id','=',$student_id)
        ->where('classtestmarks.course_code','=',$course_code)
        ->select('student_id')
        ->get();
        foreach($student_data as $data)
        {
            $stu_data=$data->student_id;
        }
        if($stu_data)
        {  
            $request->session()->flash('add', 'Student Roll Already exsits! ');
            return view('teacher/c_mark_add');
        }else{
            
            $k=0;
            $count = count(session('class_name'));
            while($k < $count) { 
                $mark=$request->mark[$k];
                if($mark>=0&&$mark<=100)
                {
                }else{
                    $request->session()->flash('add', 'please enter valid mark! ');
                    return view('teacher/c_mark_add');
                }
                
                $k++;}  
            // $rules = [
            //     'mark.*' => 'integer|between:1,100'
            // ];
    
            // $this->validate($request, $rules);
        $x=0;
        $test=array();
        DB::beginTransaction();
        try {
            $test['course_code']=session()->get('c_code');
        $test['student_id']=$request->s_id;
            foreach(session('class_name') as $category_id)
            {
                 $test['category_id'] = $category_id->id;
                 
                    while($x < $count) { 
                        
                 
                    $test['classtest_marks']=$request->mark[$x];
                    $x++;
                    break;
                      
                 
            }  
            
            DB::table('classtestmarks')->insert($test);
            }
           
           $request->session()->flash('status', 'Task was successful! ');
           DB::commit();
        } catch (\Exception $e) {
            $request->session()->flash('status', 'Task was not successful! ');
            DB::rollBack();
        }
        
           return view('teacher/c_mark_add');
        }
        
        
    }
    public function showClassTestname()
    {
        
        $classtest_names = DB::table('classtests')->where('teacher_id','abc123')
        ->paginate(4);
        return view('teacher/allClassTest',compact('classtest_names'));
    }

    public function show_c_test_mark(Request $req,$id )
    {
        $lol=0;
        $k=0;
       $datam=array();
        $class_name = DB::table('classtests')
        ->join('classtestcategories', 'classtestcategories.classtest_id', '=', 'classtests.id')
        ->where('classtests.id','=',$id)
        ->select('classtestcategories.classtest_id','classtestcategories.category_name','classtestcategories.id')
        ->get();
        $users = DB::table('classtests')
            ->join('classtestcategories', 'classtestcategories.classtest_id', '=', 'classtests.id')
            ->join('classtestmarks', 'classtestmarks.category_id', '=', 'classtestcategories.id')
            ->where('classtests.id','=',$id)
            ->select('classtestmarks.classtest_marks','classtestmarks.student_id','classtestmarks.course_code')
            ->get(); 
            foreach($class_name as $classtest_id)
            {
                $classtest_id=$classtest_id->classtest_id;
               session()->put('classtest_id',$classtest_id);
            }  
         $count=count($class_name);
         $m=0;
         $s_count=count($users);
        
         foreach($users as $data) 
         {
            if($lol != $data->student_id ){
                $value= DB::table('classtestmarks')->where('student_id', $data->student_id)
        ->where('course_code',$data->course_code)
        ->select('student_id','classtest_marks','course_code')
        ->get();
        $datam[$m]=$value;
        $m++;
            }
            else{

            }
        
        $lol=$data->student_id;
         }
        
    return view('teacher/show_C_test_mark',compact('users','datam','count','s_count','class_name'));
    }

    public function delete_c_test_mark(Request $req,$student_id,$course_code)
    {
        
        DB::table('classtestmarks')->where('student_id', $student_id)
        ->where('course_code', $course_code)
        ->delete();
        $classtest_id=session('classtest_id'); 
        $k=0;
       $m=0;
       $sid=0;
       $lol=0;
        $class_name = DB::table('classtests')
        ->join('classtestcategories', 'classtestcategories.classtest_id', '=', 'classtests.id')
        ->where('classtests.id','=',$classtest_id)
        ->select('classtestcategories.category_name','classtestcategories.id')
        ->get();
        $users = DB::table('classtests')
            ->join('classtestcategories', 'classtestcategories.classtest_id', '=', 'classtests.id')
            ->join('classtestmarks', 'classtestmarks.category_id', '=', 'classtestcategories.id')
            ->where('classtests.id','=',$classtest_id)
            ->select('classtestcategories.classtest_id','classtestmarks.classtest_marks','classtestmarks.student_id','classtests.course_code')
            ->get(); 
         $count=count($class_name);
         
         $s_count=count($users); 
         foreach($users as $data) 
         {
            if($lol != $data->student_id ){
                $value= DB::table('classtestmarks')->where('student_id', $data->student_id)
        ->where('course_code',$data->course_code)
        ->select('student_id','classtest_marks','course_code')
        ->get();
        $datam[$m]=$value;  
        $m++;
            }
            else{
                
            }
         
        
        $lol=$data->student_id;
         }
         
         $req->session()->flash('delete', 'Successfully Deleted! '); 
    return view('teacher/show_C_test_mark',compact('users','datam','sid','count','s_count','class_name'));

    }

    public function update_c_test_mark(Request $req,$student_id,$course_code)
    {
        
        
        $classtest_id=   session('classtest_id'); 
        $k=0;
       $m=0;
       $sid=0;
       $lol=0;
       $class_name = DB::table('classtests')
       ->join('classtestcategories', 'classtestcategories.classtest_id', '=', 'classtests.id')
       ->where('classtests.id','=',$classtest_id)
       ->select('classtests.classtest_name','classtestcategories.category_name','classtestcategories.id','classtestcategories.classtest_id')
       ->get();
       $users = DB::table('classtests')
           ->join('classtestcategories', 'classtestcategories.classtest_id', '=', 'classtests.id')
           ->join('classtestmarks', 'classtestmarks.category_id', '=', 'classtestcategories.id')
           ->where('classtests.id','=',$classtest_id)
           ->select('classtestcategories.classtest_id','classtestmarks.classtest_marks','classtestmarks.student_id','classtests.course_code')
           ->get(); 
         $count=count($class_name);
         session()->put('cid',$count);
         $s_count=count($users); 
         foreach($class_name as $vid)
         {
             $vname=$vid->classtest_name;
             $vid=$vid->classtest_id;
         }
         session()->put('vid',$vid);
          $value= DB::table('classtestmarks')->where('student_id', $student_id)
        ->where('course_code',$course_code)
        ->select('student_id','classtest_marks','course_code')
        ->get();
        
    return view('teacher/update_c_test_mark',compact('users','value','count','vname','vid','s_count','sid','class_name'));
      
    }

    public function edit_c_test_mark(Request $request,$student_id,$course_code)
    {
        $x=0;
        $count = session('cid');
        $test=array();
        DB::beginTransaction();
        try {
            $test['course_code']=$request->c_code;
            $test['student_id']=$request->s_id;
            foreach(session('class_id') as $id)
            {
                 $test['category_id'] = $id->id;
                    while($x < $count) { 
              
                $test['classtest_marks']=$request->mark[$x];
                $x++;break; 
            }
            DB::table('classtestmarks')
            ->where('student_id', $student_id)
            ->where('course_code',$course_code)
            ->where('category_id',$id->id)
            ->update($test);

            }
            $request->session()->flash('update', 'Successfully Upadated! ');
            DB::commit();
        } catch (\Exception $e) {
            $request->session()->flash('update', 'Dont Upadated! ');
            DB::rollBack();
        }
        $classtest_id=   session('classtest_id'); 
        $k=0;
       $m=0;
       $sid=0;
       $lol=0;
       $class_name = DB::table('classtests')
       ->join('classtestcategories', 'classtestcategories.classtest_id', '=', 'classtests.id')
       ->where('classtests.id','=',$classtest_id)
       ->select('classtestcategories.category_name','classtestcategories.id')
       ->get();
       $users = DB::table('classtests')
           ->join('classtestcategories', 'classtestcategories.classtest_id', '=', 'classtests.id')
           ->join('classtestmarks', 'classtestmarks.category_id', '=', 'classtestcategories.id')
           ->where('classtests.id','=',$classtest_id)
           ->select('classtestcategories.classtest_id','classtestmarks.classtest_marks','classtestmarks.student_id','classtests.course_code')
           ->get();  
         $count=count($class_name);
         
         $s_count=count($users); 
         foreach($users as $data) 
         {
            if($lol != $data->student_id ){
                $value= DB::table('classtestmarks')->where('student_id', $data->student_id)
        ->where('course_code',$data->course_code)
        ->select('student_id','classtest_marks','course_code')
        ->get();
        $datam[$m]=$value;  
        $m++;
            }
            else{}
         
        
        $lol=$data->student_id;
         }
         
         
    return view('teacher/show_C_test_mark',compact('users','datam','sid','count','s_count','class_name'));
    }
    public function deleteClassname(Request $request,$id)
    {
        $get_code=0;
        $get_category=DB::table('classtests')
        ->where('classtests.id','=',$id)
        ->select('course_code')
        ->get();
        foreach($get_category as $get_code)
        {
            $get_code=$get_code->course_code;
        }
        DB::table('classtests')->where('classtests.id','=',$id)
        ->delete();
        DB::table('classtestcategories')->where('classtestcategories.classtest_id','=',$id)
        ->delete();
        DB::table('classtestmarks')->where('classtestmarks.course_code','=',$get_code)
        ->delete();
        $ctest_name = DB::table('classtests')->where('teacher_id','abc123')
        ->paginate(4);
        session()->put('ctest_name',$ctest_name);
        return view('teacher/showClasstestnames',compact('ctest_name'));

    }


    //end function
}
