<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class PresentationController extends Controller
{
    public function showPname()
    {
        
        $pre_name = DB::table('presentations')->where('teacher_id','abc123')
        ->paginate(4);
        session()->put('pre_name',$pre_name);
        return view('teacher/showPresentationnames',compact('pre_name'));

    }

    public function addname(Request $request)
    {
        $c_code=0;
        $ctest_course_code = DB::table('presentations')
        ->where('teacher_id','abc123')
        ->where('course_code',$request->c_code)
        ->select('course_code')
        ->get();
        foreach($ctest_course_code as $course_code)
        {
            $c_code=$course_code->course_code;
        }
        if($c_code)
        {
            $request->session()->flash('add', 'Course Code Already exsits! ');
            return view('teacher/add_p_test_name');
        }else{
            DB::beginTransaction();
        try {
            $presentation_name=array();
        $presentation_name['teacher_id'] = 'abc123';
        $presentation_name['presentation_name'] = $request->pre_name;
        $presentation_name['course_code'] = $request->c_code;
        DB::table('presentations')->insert($presentation_name);

        $presentation_names = $request->pre_name;
        $request->session()->put('presentation_names',$presentation_names);
        
        $count=$request->count;
        if($count<1||$count>15)
        {
            $request->session()->flash('add', 'Please Enter valid Number! ');
            return view('teacher/add_p_test_name');
        }
        DB::commit();
        return view('teacher/add_pcategory_name',compact('presentation_names','count'));
    } catch (\Exception $e) {
        DB::rollback();
    }
        
        
        }
        

    }
    public function addCname(Request $request)
    {
        DB::beginTransaction();
        try {
            $pre_id=DB::table('presentations')
        ->where('presentation_name',session('presentation_names'))
        ->select('id')
        ->get();
        $test=array();
        foreach($request->get('name') as $name) {
            $test['presentation_id'] =$pre_id[0]->id;
            $test['category_name']=$name;
            DB::table('presentationcategories')->insert($test);
        }
            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
        }
        
        return redirect()->to('addP_test_mark');

    }
    public function addPtestmark(Request $req,$id )
    {
        $pre_name=0;
        
        
            $class_name = DB::table('presentations')
        ->join('presentationcategories', 'presentationcategories.presentation_id', '=', 'presentations.id')
        ->where('presentations.id','=',$id)
        ->select('presentations.presentation_name','presentations.course_code','presentationcategories.category_name','presentationcategories.id')
        ->get();
        foreach($class_name as $data)
        {
            $pre_name=$data->presentation_name;
            $c_code=$data->course_code;
        }
        if($pre_name){
            $req->session()->put('class_name',$class_name);
        $req->session()->put('pre_name',$pre_name);
        $req->session()->put('c_code',$c_code);
        
        return view('teacher/p_mark_add',compact('class_name','pre_name','c_code')); 
        }else{
            $class_name = DB::table('presentations')
        ->where('presentations.id','=',$id)
        ->select('presentations.presentation_name','presentations.course_code','presentations.teacher_id')
        ->get();
            return view('teacher/add_cP_category',compact('class_name'));
        }
        

    }
    public function addcPtname(Request $request)
    {
        $presentation_names = $request->pre_name;
        session()->put('presentation_names',$presentation_names);
        $c_code=$request->c_code;
        $count=$request->count;
        
        return view('teacher/add_pcategory_name',compact('presentation_names','count','c_code'));
    }

    public function addPmark(Request $request)
    {
        $stu_data=0;
        $student_id=$request->s_id;
        $course_code=session()->get('c_code');
        
        $student_data = DB::table('presentationmarks')
        ->where('presentationmarks.student_id','=',$student_id)
        ->where('presentationmarks.course_code','=',$course_code)
        ->select('student_id')
        ->get();
        foreach($student_data as $data)
        {
            $stu_data=$data->student_id;
        }
        if($stu_data)
        {  
            $request->session()->flash('add', 'Student Roll Already exsits! ');
            return view('teacher/p_mark_add');
        }else{
            
            $k=0;
            $count = count(session('class_name'));
            while($k < $count) { 
                $mark=$request->mark[$k];
                if($mark>=0&&$mark<=100)
                {
                }else{
                    $request->session()->flash('add', 'please enter valid mark! ');
                    return view('teacher/p_mark_add');
                }
                
                $k++;}  
            // $rules = [
            //     'mark.*' => 'integer|between:1,100'
            // ];
    
            // $this->validate($request, $rules);
            DB::beginTransaction();
            try {
                $x=0;
            $count = count(session('class_name'));
            $test=array();
            
            $test['course_code']=session()->get('c_code');
            $test['student_id']=$request->s_id;
                foreach(session('class_name') as $id)
                {
                     $test['category_id'] = $id->id;
                        while($x < $count) { 
                  
                    $test['presentation_marks']=$request->mark[$x];
                    $x++;
                        break; 
                } 
                DB::table('presentationmarks')->insert($test);
                }
               
               $request->session()->flash('status', 'Task was successful! ');
                DB::commit();
            } catch (\Exception $e) {
                DB::rollback();
            }
            
               return view('teacher/p_mark_add');
        }

        
    }
    public function showPresentationname()
    {
        
        $presentation_names = DB::table('presentations')->where('teacher_id','abc123')
        ->paginate(4);
        return view('teacher/allpresentation',compact('presentation_names'));
    }

    public function show_p_test_mark(Request $req,$id )
    {
        $lol=0;
        $k=0;
       $datam=array();
        $class_name = DB::table('presentations')
        ->join('presentationcategories', 'presentationcategories.presentation_id', '=', 'presentations.id')
        ->where('presentations.id','=',$id)
        ->select('presentationcategories.presentation_id','presentationcategories.category_name','presentationcategories.id')
        ->get();
        $users = DB::table('presentations')
            ->join('presentationcategories', 'presentationcategories.presentation_id', '=', 'presentations.id')
            ->join('presentationmarks', 'presentationmarks.category_id', '=', 'presentationcategories.id')
            ->where('presentations.id','=',$id)
            ->select('presentationmarks.presentation_marks','presentationmarks.student_id','presentationmarks.course_code')
            ->get(); 
            foreach($class_name as $pre_id)
            {
                $pre_id=$pre_id->presentation_id;
               session()->put('pre_id',$pre_id);
            }
            
         $count=count($class_name);
         $sid=0;
         $m=0;
         $s_count=count($users);
         foreach($users as $data) 
         {
            if($lol != $data->student_id ){
                $value= DB::table('presentationmarks')->where('student_id', $data->student_id)
        ->where('course_code',$data->course_code)
        ->select('student_id','presentation_marks','course_code')
        ->get();
        $datam[$m]=$value;
        $m++;
            }
            else{

            }
        
        $lol=$data->student_id;
         }
         
         
    return view('teacher/show_P_test_mark',compact('users','datam','sid','count','s_count','class_name'));
    }

    public function delete_p_test_mark(Request $req,$student_id,$course_code)
    {
        
        DB::table('presentationmarks')->where('student_id', $student_id)
        ->where('course_code', $course_code)
        ->delete();
        $presentation_id=session('pre_id'); 
        $k=0;
       $m=0;
       $mark=0;
       $lol=0;
        $class_name = DB::table('presentations')
        ->join('presentationcategories', 'presentationcategories.presentation_id', '=', 'presentations.id')
        ->where('presentations.id','=',$presentation_id)
        ->select('presentationcategories.category_name','presentationcategories.id')
        ->get();
        $users = DB::table('presentations')
            ->join('presentationcategories', 'presentationcategories.presentation_id', '=', 'presentations.id')
            ->join('presentationmarks', 'presentationmarks.category_id', '=', 'presentationcategories.id')
            ->where('presentations.id','=',$presentation_id)
            ->select('presentationcategories.presentation_id','presentationmarks.presentation_marks','presentationmarks.student_id','presentations.course_code')
            ->get(); 
         $count=count($class_name);
         
         $s_count=count($users); 
         foreach($users as $data) 
         {
            if($lol != $data->student_id ){
                $value= DB::table('presentationmarks')->where('student_id', $data->student_id)
        ->where('course_code',$data->course_code)
        ->select('student_id','presentation_marks','course_code')
        ->get();
        $datam[$m]=$value;  
        $m++;
            }
            else{}
            $lol=$data->student_id;
         }
         
         $req->session()->flash('delete', 'Successfully Deleted! '); 
    return view('teacher/show_P_test_mark',compact('users','datam','mark','count','s_count','class_name'));

    }

    public function update_p_test_mark(Request $req,$student_id,$course_code)
    {
        
        
        $pre_id=   session('pre_id'); 
        $k=0;
       $m=0;
       $sid=0;
       $lol=0;
        $class_name = DB::table('presentations')
        ->join('presentationcategories', 'presentationcategories.presentation_id', '=', 'presentations.id')
        ->where('presentations.id','=',$pre_id)
        ->select('presentations.presentation_name','presentationcategories.category_name','presentationcategories.id','presentationcategories.presentation_id')
        ->get();
        session()->put('class_id',$class_name);
        $users = DB::table('presentations')
            ->join('presentationcategories', 'presentationcategories.presentation_id', '=', 'presentations.id')
            ->join('presentationmarks', 'presentationmarks.category_id', '=', 'presentationcategories.id')
            ->where('presentations.id','=',$pre_id)
            ->select('presentationcategories.presentation_id','presentationmarks.presentation_marks','presentationmarks.student_id','presentations.course_code')
            ->get(); 
         $count=count($class_name);
         session()->put('cid',$count);
         $s_count=count($users); 
         foreach($class_name as $vid)
         {
             $vname=$vid->presentation_name;
             $vid=$vid->presentation_id;
         }
         session()->put('vid',$vid);
          $value= DB::table('presentationmarks')->where('student_id', $student_id)
        ->where('course_code',$course_code)
        ->select('student_id','presentation_marks','course_code')
        ->get();
        
    return view('teacher/update_p_test_mark',compact('users','value','count','vname','vid','s_count','sid','class_name'));
      
    }

    public function edit_p_test_mark(Request $request,$student_id,$course_code)
    {
        $x=0;
        $count = session('cid');
        $test=array();
        
        $test['course_code']=$request->c_code;
        $test['student_id']=$request->s_id;
            foreach(session('class_id') as $id)
            {
                 $test['category_id'] = $id->id;
                    while($x < $count) { 
              
                $test['presentation_marks']=$request->mark[$x];
                $x++;break; 
            }
            DB::table('presentationmarks')
            ->where('student_id', $student_id)
            ->where('course_code',$course_code)
            ->where('category_id',$id->id)
            ->update($test);
            }
        $presentation_id=   session('pre_id'); 
        $k=0;
       $m=0;
       $sid=0;
       $lol=0;
        $class_name = DB::table('presentations')
        ->join('presentationcategories', 'presentationcategories.presentation_id', '=', 'presentations.id')
        ->where('presentations.id','=',$presentation_id)
        ->select('presentationcategories.category_name','presentationcategories.id')
        ->get();
        $users = DB::table('presentations')
            ->join('presentationcategories', 'presentationcategories.presentation_id', '=', 'presentations.id')
            ->join('presentationmarks', 'presentationmarks.category_id', '=', 'presentationcategories.id')
            ->where('presentations.id','=',$presentation_id)
            ->select('presentationcategories.presentation_id','presentationmarks.presentation_marks','presentationmarks.student_id','presentations.course_code')
            ->get(); 
         $count=count($class_name);
         
         $s_count=count($users); 
         foreach($users as $data) 
         {
            if($lol != $data->student_id ){
                $value= DB::table('presentationmarks')->where('student_id', $data->student_id)
        ->where('course_code',$data->course_code)
        ->select('student_id','presentation_marks','course_code')
        ->get();
        $datam[$m]=$value;  
        $m++;
            }
            else{}
         
        
        $lol=$data->student_id;
         }
         
         $request->session()->flash('update', 'Successfully Upadated! '); 
    return view('teacher/show_P_test_mark',compact('users','datam','sid','count','s_count','class_name'));
    }

    public function deletePresentationname(Request $request,$id)
    {
        $get_code=0;
        $get_category=DB::table('presentations')
        ->where('presentations.id','=',$id)
        ->select('course_code')
        ->get();
        foreach($get_category as $get_code)
        {
            $get_code=$get_code->course_code;
        }
        DB::table('presentations')->where('presentations.id','=',$id)
        ->delete();
        DB::table('presentationcategories')->where('presentationcategories.presentation_id','=',$id)
        ->delete();
        DB::table('presentationmarks')->where('presentationmarks.course_code','=',$get_code)
        ->delete();
        return redirect()->to('home');

    }
}
