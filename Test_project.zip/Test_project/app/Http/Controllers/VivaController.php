<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class VivaController extends Controller
{
    public function showVname()
    {
        
        $viva_name = DB::table('vivanames')->where('teacher_id','abc123')
        ->paginate(4);
        session()->put('viva_name',$viva_name);
        return view('teacher/showVivanames',compact('viva_name'));

    }

    public function addname(Request $request)
    {
        $c_code=0;
        $ctest_course_code = DB::table('vivanames')
        ->where('teacher_id','abc123')
        ->where('course_code',$request->c_code)
        ->select('course_code')
        ->get();
        foreach($ctest_course_code as $course_code)
        {
            $c_code=$course_code->course_code;
        }
        if($c_code)
        {
            $request->session()->flash('add', 'Course Code Already exsits! ');
            return view('teacher/add_v_test_name');
        }else{
            DB::beginTransaction();
        try {
            $viva_name=array();
        $viva_name['teacher_id'] = 'abc123';
        $viva_name['viva_name'] = $request->viva_name;
        $viva_name['course_code'] = $request->c_code;
        DB::table('vivanames')->insert($viva_name);
        $viva_names = $request->viva_name;
        $request->session()->put('viva_names',$viva_names);
        $count=$request->count;
            DB::commit();
        } catch (\Exception $e) {
            DB::rollback();
        }
        return view('teacher/add_category_name',compact('viva_names','count'));
        }
        
    }
    public function addCname(Request $request)
    {
        $viva_id=DB::table('vivanames')
        ->where('viva_name',session('viva_names'))
        ->select('id')
        ->get();
        $test=array();
        foreach($request->get('name') as $name) {
            $test['viva_id'] =$viva_id[0]->id;
            $test['category_name']=$name;
            DB::table('vivacategories')->insert($test);
        }
        return redirect()->to('addV_test_mark');

    }
    public function addVtestmark(Request $req,$id )
    {
        $viva_name=0;
        $class_name = DB::table('vivanames')
        ->join('vivacategories', 'vivacategories.viva_id', '=', 'vivanames.id')
        ->where('vivanames.id','=',$id)
        ->select('vivanames.viva_name','vivanames.course_code','vivacategories.category_name','vivacategories.id')
        ->get();
        foreach($class_name as $data)
        {
            $viva_name=$data->viva_name;
            $c_code=$data->course_code;
        }
        if($viva_name){
            $req->session()->put('class_name',$class_name);
            $req->session()->put('viva_name',$viva_name);
            $req->session()->put('c_code',$c_code);
            return view('teacher/v_mark_add',compact('class_name','viva_name','c_code')); 
        }else{
            $class_name = DB::table('vivanames')
        ->where('vivanames.id','=',$id)
        ->select('vivanames.viva_name','vivanames.course_code','vivanames.teacher_id')
        ->get();
            return view('teacher/add_cV_category',compact('class_name'));
        }
        
        

    }

    public function addcVtname(Request $request)
    {
        $viva_names = $request->viva_name;
        session()->put('viva_names',$viva_names);
        $c_code=$request->c_code;
        $count=$request->count;
        return view('teacher/add_category_name',compact('viva_names','count','c_code'));
    }

    public function addVmark(Request $request)
    {
        $stu_data=0;
        $student_id=$request->s_id;
        $x=0;
        $count = count(session('class_name'));
        $course_code=session()->get('c_code');
        $student_data = DB::table('vivamarks')
        ->where('vivamarks.student_id','=',$student_id)
        ->where('vivamarks.course_code','=',$course_code)
        ->select('student_id')
        ->get();
        foreach($student_data as $data)
        {
            $stu_data=$data->student_id;
        }

        if($stu_data)
        {  
            $request->session()->flash('add', 'Student Roll Already exsits! ');
            return view('teacher/v_mark_add');
        }else{
            
            $k=0;
            $count = count(session('class_name'));
            while($k < $count) { 
                $mark=$request->mark[$k];
                if($mark>=0&&$mark<=100)
                {
                }else{
                    $request->session()->flash('add', 'please enter valid mark! ');
                    return view('teacher/v_mark_add');
                }
                
                $k++;}  
            // $rules = [
            //     'mark.*' => 'integer|between:1,100'
            // ];
    
            // $this->validate($request, $rules);
            $test=array();
            DB::beginTransaction();
            try {
                $test['course_code']=session()->get('c_code');
            $test['student_id']=$request->s_id;
                foreach(session('class_name') as $category_id)
                {
                     $test['category_id'] = $category_id->id;
                     
                        while($x < $count) { 
                            
                    $test['viva_marks']=$request->mark[$x];
                    $x++;
                        break; 
                }  
                
                DB::table('vivamarks')->insert($test);
                }
               
               $request->session()->flash('status', 'Task was successful! ');
               DB::commit();
            } catch (\Exception $e) {
                $request->session()->flash('status', 'Task was not successful! ');
                DB::rollBack();
            }
            
               return view('teacher/v_mark_add');
        }


        
    }
    public function showVivaname()
    {
        
        $viva_names = DB::table('vivanames')->where('teacher_id','abc123')
        ->paginate(4);
        return view('teacher/allviva',compact('viva_names'));
    }

    public function show_v_test_mark(Request $req,$id )
    {
        $lol=0;
        $k=0;
       $datam=array();
        $class_name = DB::table('vivanames')
        ->join('vivacategories', 'vivacategories.viva_id', '=', 'vivanames.id')
        ->where('vivanames.id','=',$id)
        ->select('vivacategories.viva_id','vivacategories.category_name','vivacategories.id')
        ->get();
        $users = DB::table('vivanames')
            ->join('vivacategories', 'vivacategories.viva_id', '=', 'vivanames.id')
            ->join('vivamarks', 'vivamarks.category_id', '=', 'vivacategories.id')
            ->where('vivanames.id','=',$id)
            ->select('vivamarks.viva_marks','vivamarks.student_id','vivamarks.course_code')
            ->get(); 
            foreach($class_name as $viva_id)
            {
                $viva_id=$viva_id->viva_id;
               session()->put('viva_id',$viva_id);
            }  
         $count=count($class_name);
         $m=0;
         $s_count=count($users);
        
         foreach($users as $data) 
         {
            if($lol != $data->student_id ){
                $value= DB::table('vivamarks')->where('student_id', $data->student_id)
        ->where('course_code',$data->course_code)
        ->select('student_id','viva_marks','course_code')
        ->get();
        $datam[$m]=$value;
        $m++;
            }
            else{

            }
        
        $lol=$data->student_id;
         }
        
    return view('teacher/show_V_test_mark',compact('users','datam','count','s_count','class_name'));
    }

    public function delete_v_test_mark(Request $req,$student_id,$course_code)
    {
        
        DB::table('vivamarks')->where('student_id', $student_id)
        ->where('course_code', $course_code)
        ->delete();
        $viva_id=session('viva_id'); 
        $k=0;
       $m=0;
       $sid=0;
       $lol=0;
        $class_name = DB::table('vivanames')
        ->join('vivacategories', 'vivacategories.viva_id', '=', 'vivanames.id')
        ->where('vivanames.id','=',$viva_id)
        ->select('vivacategories.category_name','vivacategories.id')
        ->get();
        $users = DB::table('vivanames')
            ->join('vivacategories', 'vivacategories.viva_id', '=', 'vivanames.id')
            ->join('vivamarks', 'vivamarks.category_id', '=', 'vivacategories.id')
            ->where('vivanames.id','=',$viva_id)
            ->select('vivacategories.viva_id','vivamarks.viva_marks','vivamarks.student_id','vivanames.course_code')
            ->get(); 
         $count=count($class_name);
         
         $s_count=count($users); 
         foreach($users as $data) 
         {
            if($lol != $data->student_id ){
                $value= DB::table('vivamarks')->where('student_id', $data->student_id)
        ->where('course_code',$data->course_code)
        ->select('student_id','viva_marks','course_code')
        ->get();
        $datam[$m]=$value;  
        $m++;
            }
            else{
                
            }
         
        
        $lol=$data->student_id;
         }
         
         $req->session()->flash('delete', 'Successfully Deleted! '); 
    return view('teacher/show_V_test_mark',compact('users','datam','sid','count','s_count','class_name'));

    }

    public function update_v_test_mark(Request $req,$student_id,$course_code)
    {
        
        
        $viva_id=   session('viva_id'); 
        $k=0;
       $m=0;
       $sid=0;
       $lol=0;
        $class_name = DB::table('vivanames')
        ->join('vivacategories', 'vivacategories.viva_id', '=', 'vivanames.id')
        ->where('vivanames.id','=',$viva_id)
        ->select('vivanames.viva_name','vivacategories.category_name','vivacategories.id','vivacategories.viva_id')
        ->get();
        session()->put('class_id',$class_name);
        $users = DB::table('vivanames')
            ->join('vivacategories', 'vivacategories.viva_id', '=', 'vivanames.id')
            ->join('vivamarks', 'vivamarks.category_id', '=', 'vivacategories.id')
            ->where('vivanames.id','=',$viva_id)
            ->select('vivacategories.viva_id','vivamarks.viva_marks','vivamarks.student_id','vivanames.course_code')
            ->get(); 
         $count=count($class_name);
         session()->put('cid',$count);
         $s_count=count($users); 
         foreach($class_name as $vid)
         {
             $vname=$vid->viva_name;
             $vid=$vid->viva_id;
         }
         session()->put('vid',$vid);
          $value= DB::table('vivamarks')->where('student_id', $student_id)
        ->where('course_code',$course_code)
        ->select('student_id','viva_marks','course_code')
        ->get();
        
    return view('teacher/update_v_test_mark',compact('users','value','count','vname','vid','s_count','sid','class_name'));
      
    }

    public function edit_v_test_mark(Request $request,$student_id,$course_code)
    {
        $x=0;
        $count = session('cid');
        $test=array();
        DB::beginTransaction();
        try {
            $test['course_code']=$request->c_code;
            $test['student_id']=$request->s_id;
            foreach(session('class_id') as $id)
            {
                 $test['category_id'] = $id->id;
                    while($x < $count) { 
              
                $test['viva_marks']=$request->mark[$x];
                $x++;break; 
            }
            DB::table('vivamarks')
            ->where('student_id', $student_id)
            ->where('course_code',$course_code)
            ->where('category_id',$id->id)
            ->update($test);

            }
            $request->session()->flash('update', 'Successfully Upadated! ');
            DB::commit();
        } catch (\Exception $e) {
            $request->session()->flash('update', 'Dont Upadated! ');
            DB::rollBack();
        }
        $viva_id=   session('viva_id'); 
        $k=0;
       $m=0;
       $sid=0;
       $lol=0;
        $class_name = DB::table('vivanames')
        ->join('vivacategories', 'vivacategories.viva_id', '=', 'vivanames.id')
        ->where('vivanames.id','=',$viva_id)
        ->select('vivacategories.category_name','vivacategories.id')
        ->get();
        $users = DB::table('vivanames')
            ->join('vivacategories', 'vivacategories.viva_id', '=', 'vivanames.id')
            ->join('vivamarks', 'vivamarks.category_id', '=', 'vivacategories.id')
            ->where('vivanames.id','=',$viva_id)
            ->select('vivacategories.viva_id','vivamarks.viva_marks','vivamarks.student_id','vivanames.course_code')
            ->get(); 
         $count=count($class_name);
         
         $s_count=count($users); 
         foreach($users as $data) 
         {
            if($lol != $data->student_id ){
                $value= DB::table('vivamarks')->where('student_id', $data->student_id)
        ->where('course_code',$data->course_code)
        ->select('student_id','viva_marks','course_code')
        ->get();
            }
            else
        break;
         
        $datam[$m]=$value;  
        $m++;
        $lol=$users[0]->student_id;
         }
         
         
    return view('teacher/show_V_test_mark',compact('users','datam','sid','count','s_count','class_name'));
    }
    public function deleteVivaname(Request $request,$id)
    {
        $get_code=0;
        $get_category=DB::table('vivanames')
        ->where('vivanames.id','=',$id)
        ->select('course_code')
        ->get();
        foreach($get_category as $get_code)
        {
            $get_code=$get_code->course_code;
        }
        DB::table('vivanames')->where('vivanames.id','=',$id)
        ->delete();
        DB::table('vivacategories')->where('vivacategories.viva_id','=',$id)
        ->delete();
        DB::table('vivamarks')->where('vivamarks.course_code','=',$get_code)
        ->delete();
        return redirect()->to('home');

    }
    
    //end of function
}
