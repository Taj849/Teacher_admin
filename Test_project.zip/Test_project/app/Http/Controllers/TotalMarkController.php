<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class TotalMarkController extends Controller
{
    public function getCode(Request $request)
    {
        $classtest_course_code=array();
        $viva_course_code=array();
        $presentation_course_code=array();
        $total_code=array();
        $cls_data=array();
        $viva_data=array();
        $presentation_data=array();
        $c=0;
        $v=0;
        $p=0;
        //initial data end
        $classtest_course_code = DB::table('classtests')
        ->where('classtests.teacher_id','=','abc123')
        ->select('course_code')
        ->get();
        $viva_course_code = DB::table('vivanames')
        ->where('vivanames.teacher_id','=','abc123')
        ->select('course_code')
        ->get();
        $presentation_course_code = DB::table('presentations')
        ->where('presentations.teacher_id','=','abc123')
        ->select('course_code')
        ->get();
        foreach($classtest_course_code as $data)
    {
        $cls_data[$c]=$data->course_code;
        $c++;
    }
    foreach($viva_course_code as $data)
    {
        $viva_data[$v]=$data->course_code;
        $v++;
    }
    foreach($presentation_course_code as $data)
    {
        $presentation_data[$p]=$data->course_code;
        $p++;
    }
        $total_code=array_unique(array_merge($cls_data,$viva_data,$presentation_data));
       
       return view('teacher/totalCourseCode',compact('total_code'));

    }

   public function showtotalmark(Request $req,$course_code)
   {
       $viva_mark=0;
       $class_mark=0;
       $presentation_mark=0;
       $big=0;
       $p=0;
       $q=0;
       $n=0;
       $e=0;
       $c_id=0;
       $l=0;
       $data=0;
       $v_data=0;
       $data2=0;
       $sum=0;
       $k=0;
       $total=0;
       $m=0;
       $class_data=0;
       $presentation_data=0;
       $pre_data=0;
       $viva_data=0;
       $student_data=array();
       $total_mark=array();
       $vstudent_data=array();
       $vtotal_mark=array();
       $pstudent_data=array();
       $ptotal_mark=array();
    $class_name = DB::table('classtests')
    ->where('classtests.teacher_id','=','abc123')
    ->where('classtests.course_code','=',$course_code)
    ->select('course_code')
    ->get();
    $viva_name = DB::table('vivanames')
    ->where('vivanames.teacher_id','=','abc123')
    ->where('vivanames.course_code','=',$course_code)
    ->select('course_code')
    ->get();
    $presentation_name = DB::table('presentations')
    ->where('presentations.teacher_id','=','abc123')
    ->where('presentations.course_code','=',$course_code)
    ->select('course_code')
    ->get();

    foreach($class_name as $data)
    {
        $class_data=$data->course_code;
    }
    foreach($viva_name as $data)
    {
        $viva_data=$data->course_code;
    }
    foreach($presentation_name as $data)
    {
        $presentation_data=$data->course_code;
    }
    if($class_data){
        $class_test = DB::table('classtestmarks')
    ->where('classtestmarks.course_code','=',$class_data)
    ->select('student_id','course_code','classtest_marks')
    ->get();
    $classTest_total_count=count($class_test);
    for($l=0;$l<$classTest_total_count;$l++)
    {
        if($data!=$class_test[$l]->student_id)
        {
            $total = DB::table('classtestmarks')
    ->where('classtestmarks.course_code','=',$class_data)
    ->where('classtestmarks.student_id','=',$class_test[$l]->student_id)
    ->sum('classtest_marks');
            $data=$class_test[$l]->student_id;
            $student_data[$e]=$class_test[$l]->student_id;
            $total_mark[$e]=$total;
            $e++;
        } 
    }
    }
    if($viva_data){
        $viva_test = DB::table('vivamarks')
    ->where('vivamarks.course_code','=',$viva_data)
    ->select('student_id','course_code','viva_marks')
    ->get();
    $viva_total_count=count($viva_test);
    for($l=0;$l<$viva_total_count;$l++)
    {
        if($v_data!=$viva_test[$l]->student_id)
        {
            $total = DB::table('vivamarks')
    ->where('vivamarks.course_code','=',$viva_data)
    ->where('vivamarks.student_id','=',$viva_test[$l]->student_id)
    ->sum('viva_marks');
            $v_data=$viva_test[$l]->student_id;
            
            $vstudent_data[$q]=$viva_test[$l]->student_id;
            $vtotal_mark[$q]=$total;
            $q++;
        } 
    }
    
    
    
    
    }
    if($presentation_data){
        
        $presentation_test = DB::table('presentationmarks')
    ->where('presentationmarks.course_code','=',$presentation_data)
    ->select('student_id','course_code','presentation_marks')
    ->get();
    $presentation_total_count=count($presentation_test);
    for($l=0;$l<$presentation_total_count;$l++)
    {
        if($pre_data!=$presentation_test[$l]->student_id)
        {
            $total = DB::table('presentationmarks')
    ->where('presentationmarks.course_code','=',$presentation_data)
    ->where('presentationmarks.student_id','=',$presentation_test[$l]->student_id)
    ->sum('presentation_marks');
            $pre_data=$presentation_test[$l]->student_id;
            
            $pstudent_data[$n]=$presentation_test[$l]->student_id;
            $ptotal_mark[$n]=$total;
            $n++;
           
        } 
    }
    
    
    }
    
    $data_merge=array_unique(array_merge($vstudent_data,$student_data,$pstudent_data));
    
        return view('teacher/totalMark',compact('viva_mark','class_mark','presentation_mark','data_merge','e','q','n','total_mark','vtotal_mark','ptotal_mark','student_data','vstudent_data','pstudent_data','course_code'));
    
    
    // sort($data_merge);
    
     
   }
}
