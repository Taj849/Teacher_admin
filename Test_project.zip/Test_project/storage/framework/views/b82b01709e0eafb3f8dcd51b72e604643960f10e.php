<?php $__env->startSection('body'); ?>

<!--outter-wp-->
<div class="outter-wp">
    <!--sub-heard-part-->
      <div class="sub-heard-part">
       <ol class="breadcrumb m-b-0">
            <li><a href="index.html">Home</a></li>
            <li class="active">Tables</li>
        </ol>
       </div>
  <!--//sub-heard-part-->
  <!--/forms-->
  <div class="forms-main">
    
    <h2 class="inner-tittle">Update <?php echo e($vname); ?>  Mark</h2>
        <div class="graph-form">
                <div class="validation-form">
                            <!---->
                                
                <form action="/editVtestmark/<?php echo e($value[0]->student_id); ?>/<?php echo e($value[0]->course_code); ?> " method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="vali-form">
                                      <div class="col-md-6 form-group1">
                                        <label class="control-label">Viva name</label>
                                        <input type="text" value="<?php echo e($vname); ?>" name="viva_name" required="">
                                      </div>
                                      <div class="col-md-6 form-group1 form-last">
                                        <label class="control-label">Course Code</label>
                                        <input type="text" value="<?php echo e($value[0]->course_code); ?>" name="c_code" required="">
                                      </div>   
                                     
                                        <div class="col-md-6 form-group1">
                                            <label class="control-label">Student Id</label>
                                            <input type="text" value="<?php echo e($value[0]->student_id); ?>" name="s_id" required="">
                                          </div>
                                          <div class="clearfix"> </div>
                                          <?php $__currentLoopData = $class_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <div class="col-md-6 form-group1">
                                            <label class="control-label"><?php echo e($item->category_name); ?></label>
                                           <?php for($i = $sid; $i < $count; $i++): ?>
                                           <input type="text" value="<?php echo e($value[$i]->viva_marks); ?>" name="mark[]" required="">
                                           <?php
                                               $sid++;
                                          break;
                                           ?>
                                           <?php endfor; ?>
                                            
                                          </div>
                                          <div class="clearfix"> </div>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                                    <div class="clearfix"> </div>
                                    <div class="col-md-12 form-group button-2">
                                      <button type="submit" onclick="return confirm('Are you sure you want to Update this item?');" class="btn btn-primary">Save</button>
                                      
                                    </div>
                                  <div class="clearfix"> </div>
                                </form>
                            
                            <!---->
                         </div>

                    </div>
            </div> 
    <!--//forms-->											   
</div>
<!--//outer-wp-->
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Test_project\resources\views/teacher/update_v_test_mark.blade.php ENDPATH**/ ?>