<?php $__env->startSection('body'); ?>

<!--outter-wp-->
<div class="outter-wp">
    <!--sub-heard-part-->
      <div class="sub-heard-part">
       <ol class="breadcrumb m-b-0">
            <li><a href="index.html">Home</a></li>
            <li class="active">Tables</li>
        </ol>
       </div>
  <!--//sub-heard-part-->
  <!--/forms-->
  <div class="forms-main">
    <h2 class="inner-tittle">Add ClassTest Name</h2>
        <div class="graph-form">
                <div class="validation-form">
                    <div>


                        <form action="<?php echo e(url('addVcategoryname')); ?>" method="post" >
                            <?php echo csrf_field(); ?>
                        <?php $__currentLoopData = $class_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="vali-form">
                            <div class="col-md-6 form-group1">
                              <label class="control-label">Viva Name</label>
                              <input type="text" value="<?php echo e($item->viva_name); ?>" name="viva_name" required="">
                            </div>
                            <div class="col-md-6 form-group1 form-last">
                              <label class="control-label">Course Code</label>
                              <input type="text" value="<?php echo e($item->course_code); ?>" name="c_code" required="">
                            </div>
                            <div class="clearfix"> </div>
                                <div class="col-md-6 form-group1 form-last">
                                <label class="control-label"><strong>How many category want to add</strong>  </label>
                                <input type="text" placeholder="Category No"  required="" name="count">   
                            </div>
                            <div class="clearfix"> </div>
                            <div class="col-md-12 form-group button-2">
                              <button  class="btn btn-primary" type="submit">Add Name</button> 
                            </div>
                          </div>
                          <div class="clearfix"> </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                        
                        
                        </form>
                        </div>
                         </div>

                    </div>
            </div> 
    <!--//forms-->											   
</div>
<!--//outer-wp-->
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Test_project\resources\views/teacher/add_cV_category.blade.php ENDPATH**/ ?>