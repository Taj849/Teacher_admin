<?php $__env->startSection('body'); ?>

<!--outter-wp-->
<div class="outter-wp">
    <!--sub-heard-part-->
      <div class="sub-heard-part">
       <ol class="breadcrumb m-b-0">
            <li><a href="index.html">Home</a></li>
            <li class="active">Tables</li>
        </ol>
       </div>
  <!--//sub-heard-part-->
  <div class="col-md-6 " style="margin-bottom: 20px">
    <h3 class="sub-tittle">Viva Name </h3>
    
     

    <?php $__currentLoopData = session('viva_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    
       <ul class="timeline">
           <li>
             <div class="timeline-badge success"><i class="fa fa-check-circle-o"></i></div>
             <div class="timeline-panel">
              
               <div class="timeline-heading">
               <h4 class="timeline-title"><a href="addvtestmark/<?php echo e($item->id); ?>"><?php echo e($item->viva_name); ?></a>   </h4>

               <div class="timeline-action">
                <a  href="index.html" class="tooltips"><span>Edit</span><i class="fa fa-edit" style='font-size:15px;'></i></a>
                <a  href="/deleteVivaname/<?php echo e($item->id); ?>"onclick="return confirm('Are you sure you want to delete this item?');" class="tooltips"><span>Delete</span><i class="fa fa-trash-o" style='font-size:15px;'></i></a>

               </div>
               
               
               </div>

             </div>
           </li>
       </ul>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
       
       <div style="margin-bottom: 10px;text-align:center">
        <?php echo e($viva_name->links()); ?> 
       </div>
   </div>
   
   
   <div class="col-md-6 ">
    <p class="four">
        <a class="a_demo_four" href="<?php echo e(url('addV_test_name')); ?>">
            Add New Viva !
        </a>
     </p>
       
   </div>
   
  
    <!--//outer-wp-->
  
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Test_project\resources\views/teacher/showVivanames.blade.php ENDPATH**/ ?>