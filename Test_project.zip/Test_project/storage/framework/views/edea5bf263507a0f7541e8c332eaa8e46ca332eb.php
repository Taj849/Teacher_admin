<?php $__env->startSection('body'); ?>

<!--outter-wp-->
<div class="outter-wp">
    <!--sub-heard-part-->
      <div class="sub-heard-part">
       <ol class="breadcrumb m-b-0">
            <li><a href="index.html">Home</a></li>
            <li class="active">Tables</li>
        </ol>
       </div>
  <!--//sub-heard-part-->
    <div class="graph-visual tables-main">
      
      <p style="float: right">
        <a class="a_demo_three" href="#">
          Active!
        </a>
      </p>
      
            <h2 class="inner-tittle">Viva Mark</h2>
            <?php if(session('delete')): ?>
                            <div class="alert alert-success">
                              <?php echo e(session('delete')); ?>

                            </div>
                          <?php endif; ?>
                          <?php if(session('update')): ?>
                          <div class="alert alert-success">
                            <?php echo e(session('update')); ?>

                          </div>
                        <?php endif; ?>
                <div class="graph">
                        <div class="tables">
                                <?php if($count): ?>
                                <table class="table">
                                    <thead>
                                        <tr>
                                          <th>Student Id</th>
                                          <th>Course Code</th>
                                        <?php $__currentLoopData = $class_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <th><?php echo e($item->category_name); ?></th>  
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           <th>Action</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        <?php
                                            $mark=0;
                                        ?>
                                        <?php for($j=0;$j<$s_count/$count;$j++): ?>
                                        <tr>
                                         
                                        <?php for($i=0;$i<$count;$i++): ?>
                                          <?php if($mark!=$datam[$j][$i]->student_id): ?>
                                          <td><?php echo e($datam[$j][$i]->student_id); ?></td>
                                          <td><?php echo e($datam[$j][$i]->course_code); ?></td>
                                          <?php endif; ?>
                                            <?php
                                                $mark=$datam[$j][$i]->student_id;
                                            ?>
                                                
                                                <td><?php echo e($datam[$j][$i]->viva_marks); ?></td>
                                        <?php endfor; ?>
                                                
                                                <td>
                                                <a  href="/updateVtestmark/<?php echo e($datam[$j][$i-1]->student_id); ?>/<?php echo e($datam[$j][$i-1]->course_code); ?>" class="tooltips"><span>Edit</span><i class="fa fa-edit" style='font-size:24px;padding-raight:10px;'></i></a>
                                                <a  href="/deleteVtestmark/<?php echo e($datam[$j][$i-1]->student_id); ?>/<?php echo e($datam[$j][$i-1]->course_code); ?>"class="tooltips" onclick="return confirm('Are you sure you want to delete this item?');">
                                                  <span>Delete</span>
                                                  <i class="fa fa-trash-o" style='font-size:24px; padding-left:10px;'></i>
                                                </a>
                                                  </td>
                                                        
                                        </tr>
                                        <?php endfor; ?> 
                                        
                                            
                                    </tbody>
                                </table>
                                <?php endif; ?>
                            </div>
                </div>
        </div>
        <!--//graph-visual-->
    </div>
    <!--//outer-wp-->
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Test_project\resources\views/teacher/show_V_test_mark.blade.php ENDPATH**/ ?>