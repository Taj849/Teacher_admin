<?php $__env->startSection('body'); ?>

<!--outter-wp-->
<div class="outter-wp">
    <!--sub-heard-part-->
      <div class="sub-heard-part">
       <ol class="breadcrumb m-b-0">
            <li><a href="index.html">Home</a></li>
            <li class="active">Tables</li>
        </ol>
       </div>
  <!--//sub-heard-part-->
  <!--/forms-->
  <div class="forms-main">
    <h2 class="inner-tittle">Add <?php echo e(session('classtest_names')); ?> Category Name</h2>
        <div class="graph-form">
                <div class="validation-form">
                            <!---->
                                
                <form action="<?php echo e(url('addpCtname')); ?> " method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="vali-form">
                                          <div class="clearfix"> </div>
                                          <div class="col-md-6 form-group1 form-last">
                                            <label class="control-label"> Now Add Category</label>
                                            
                                          </div>
                                        <?php for($i = 0; $i < $count; $i++): ?>
                                        <div class="clearfix"> </div>
                                        <div class="col-md-6 form-group1 form-last">
                                            
                                        <input type="text"  name="name[]" required="">   
                                        </div>
                                        <?php endfor; ?>
                                    
                                    <div class="clearfix"> </div>
                                    <div class="col-md-12 form-group button-2">
                                      <button type="submit" class="btn btn-primary">Save</button>
                                      
                                    </div>
                                  <div class="clearfix"> </div>
                                </form>
                            
                            <!---->
                         </div>

                    </div>
            </div> 
    <!--//forms-->											   
</div>
<!--//outer-wp-->
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Test_project\resources\views/teacher/add_ctcategory_name.blade.php ENDPATH**/ ?>