<?php $__env->startSection('body'); ?>

<!--outter-wp-->
<div class="outter-wp">
    <!--sub-heard-part-->
      <div class="sub-heard-part">
       <ol class="breadcrumb m-b-0">
            <li><a href="index.html">Home</a></li>
            <li class="active">Tables</li>
        </ol>
       </div>
  <!--//sub-heard-part-->
  <!--/forms-->
  <div class="forms-main">
    <h2 class="inner-tittle">Add Presentation Name</h2>
        <div class="graph-form">
                <div class="validation-form">
                    <div>
                      <?php if(session()->has('add')): ?>
                            <div class="alert alert-danger">
                              <?php echo e(session('add')); ?>

                            </div>
                          <?php endif; ?>

                        <form action="<?php echo e(url('addcategoryname')); ?>" method="post" >
                            <?php echo csrf_field(); ?>
                            
                        <div class="vali-form">
                            <div class="col-md-6 form-group1">
                              <label class="control-label">Viva Name</label>
                              <input type="text" placeholder="Viva name" name="viva_name" required="">
                            </div>
                            <div class="col-md-6 form-group1 form-last">
                              <label class="control-label">Course Code</label>
                              <input type="text" placeholder="Course Code" name="c_code" required="">
                            </div>
                            <div class="clearfix"> </div>
                                <div class="col-md-6 form-group1 form-last">
                                <label class="control-label"><strong>How many category want to add</strong>  </label>
                                <input type="text" placeholder="Category No"  required="" name="count">   
                            </div>
                            <div class="clearfix"> </div>
                            <div class="col-md-12 form-group button-2">
                              <button  class="btn btn-primary" type="submit">Add Name</button> 
                            </div>
                          </div>
                          <div class="clearfix"> </div>
                        
                        </form>
                        </div>
                         </div>

                    </div>
            </div> 
    <!--//forms-->											   
</div>
<!--//outer-wp-->
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Test_project\resources\views/teacher/add_v_test_name.blade.php ENDPATH**/ ?>