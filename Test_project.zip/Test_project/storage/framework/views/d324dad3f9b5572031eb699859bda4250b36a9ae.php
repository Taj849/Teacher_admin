<?php $__env->startSection('body'); ?>

<!--outter-wp-->
<div class="outter-wp">
    <!--sub-heard-part-->
      <div class="sub-heard-part">
       <ol class="breadcrumb m-b-0">
            <li><a href="index.html">Home</a></li>
            <li class="active">Tables</li>
        </ol>
       </div>
  <!--//sub-heard-part-->
  <!--/forms-->
  <div class="forms-main">
    
    <h2 class="inner-tittle">Add <?php echo e(session('viva_name')); ?> Viva Test Mark</h2>
        <div class="graph-form">
                <div class="validation-form">
                            <!---->
                                
                <form action="<?php echo e(url('addVmark')); ?> " method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php if(session()->has('status')): ?>
                            <div class="alert alert-success">
                              <?php echo e(session('status')); ?>

                            </div>
                          <?php endif; ?>
                          <?php if(session()->has('add')): ?>
                            <div class="alert alert-danger">
                              <?php echo e(session('add')); ?>

                            </div>
                          <?php endif; ?>
                                    <div class="vali-form">
                                      <div class="col-md-6 form-group1">
                                        <label class="control-label">Viva name</label>
                                        <input type="text" value="<?php echo e(session('viva_name')); ?>" name="viva_name" required="">
                                      </div>
                                      <div class="col-md-6 form-group1 form-last">
                                        <label class="control-label">Course Code</label>
                                        <input type="text" value="<?php echo e(session('c_code')); ?>" name="c_code" required="">
                                      </div>   
                                     
                                        <div class="col-md-6 form-group1">
                                            <label class="control-label">Student Id</label>
                                            <input type="text" value="" name="s_id" required="">
                                          </div>
                                          <div class="clearfix"> </div>
                                          <?php $__currentLoopData = session('class_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <div class="col-md-6 form-group1">
                                            <label class="control-label"><?php echo e($item->category_name); ?></label>
                                           
                                            <input type="text" value="" name="mark[]" required="">
                                          </div>
                                          <div class="clearfix"> </div>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                                    <div class="clearfix"> </div>
                                    <div class="col-md-12 form-group button-2">
                                      <button type="submit" class="btn btn-primary">Save</button>
                                      
                                    </div>
                                  <div class="clearfix"> </div>
                                </form>
                            
                            <!---->
                         </div>

                    </div>
            </div> 
    <!--//forms-->											   
</div>
<!--//outer-wp-->
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Test_project\resources\views/teacher/v_mark_add.blade.php ENDPATH**/ ?>