<?php $__env->startSection('body'); ?>

<!--outter-wp-->
<div class="outter-wp">
    <!--sub-heard-part-->
      <div class="sub-heard-part">
       <ol class="breadcrumb m-b-0">
            <li><a href="index.html">Home</a></li>
            <li class="active">Tables</li>
        </ol>
       </div>
  <!--//sub-heard-part-->
    <div class="graph-visual tables-main">
      
      <p style="float: right">
        <a class="a_demo_three" href="#">
          Active!
        </a>
      </p>
      
            <h2 class="inner-tittle">Total <?php echo e($course_code); ?> Mark</h2>
                <div class="graph">
                        <div class="tables">
                                
                                <table class="table">
                                    <thead>
                                        <tr>
                                          <th>Student Id</th>
                                          <th>Course Code</th>
                                          <th>ClassTest Mark</th>
                                          <th>Viva Mark</th>
                                          <th>Presentation Mark</th>
                                           <th>Total Mark</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        <?php $__currentLoopData = $data_merge; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <?php
                                                $sum=0;
                                            ?>
                                            <td><?php echo e($data); ?></td>
                                            <td><?php echo e($course_code); ?></td>
                                        <?php for($b=0;$b<$e;$b++): ?>
                                            <?php if($data==$student_data[$b]): ?>
                                            
                                            <?php
                                                $class_mark=$total_mark[$b];
                                                $sum=$sum+$total_mark[$b];
                                            ?>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                        <?php if($class_mark): ?>
                                        <td><?php echo e($class_mark); ?></td>
                                        <?php
                                            $class_mark=0;
                                        ?>
                                        <?php else: ?>
                                            <td></td>
                                        <?php endif; ?>
                                        <?php for($b=0;$b<$q;$b++): ?>
                                            <?php if($data==$vstudent_data[$b]): ?>
                                            
                                            <?php
                                               $viva_mark= $vtotal_mark[$b];
                                                $sum=$sum+$vtotal_mark[$b];
                                            ?>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                        <?php if($viva_mark): ?>
                                        <td><?php echo e($viva_mark); ?></td>
                                        <?php
                                            $viva_mark=0;
                                        ?>
                                        <?php else: ?>
                                        <td></td>
                                        <?php endif; ?>
                                        <?php for($b=0;$b<$n;$b++): ?>
                                        
                                            <?php if($data==$pstudent_data[$b]): ?>
                                            
                                            <?php
                                            $presentation_mark=$ptotal_mark[$b];
                                            $sum=$sum+$ptotal_mark[$b];
                                            ?>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                        <?php if($presentation_mark): ?>
                                        <td><?php echo e($presentation_mark); ?></td>
                                        <?php
                                            $presentation_mark=0;
                                        ?>
                                        <?php else: ?>
                                            <td></td>
                                        <?php endif; ?>
                                        <td><?php echo e($sum); ?></td> 
                                        </tr>   
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                
                            </div>
                </div>
        </div>
        <!--//graph-visual-->
    </div>
    <!--//outer-wp-->
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Test_project\resources\views/teacher/totalMark.blade.php ENDPATH**/ ?>