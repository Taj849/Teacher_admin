<?php
use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/home', function () {
    return view('teacher/home');
});

//viva section
Route::get('/addV_test_mark','VivaController@showVname');

Route::view('/addV_test_name','teacher/add_v_test_name');

Route::post('/addcategoryname','VivaController@addname');
Route::post('/addVcategoryname','VivaController@addcVtname');
Route::post('/addCname','VivaController@addCname');

Route::get('addvtestmark/{id}','VivaController@addVtestmark');

Route::post('addVmark','VivaController@addVmark');

Route::get('/showV_test_mark','VivaController@showVivaname');

Route::get('showVtestmark/{id}','VivaController@show_v_test_mark');

Route::get('deleteVtestmark/{student_id}/{course_code}','VivaController@delete_v_test_mark');

Route::get('updateVtestmark/{student_id}/{course_code}','VivaController@update_v_test_mark');

Route::post('editVtestmark/{student_id}/{course_code}','VivaController@edit_v_test_mark');


Route::get('deleteVivaname/{id}','VivaController@deleteVivaname');



//end of viva section

//start presentation section
Route::get('/addP_test_mark','PresentationController@showPname');

Route::view('/addP_test_name','teacher/add_p_test_name');

Route::post('/addpcategoryname','PresentationController@addname');
Route::post('/addPcategoryname','PresentationController@addcPtname');
Route::post('/addpCname','PresentationController@addCname');

Route::get('addptestmark/{id}','PresentationController@addPtestmark');

Route::post('addPmark','PresentationController@addPmark');

Route::get('/showP_test_mark','PresentationController@showPresentationname');

Route::get('showPtestmark/{id}','PresentationController@show_p_test_mark');

Route::get('deletePtestmark/{student_id}/{course_code}','PresentationController@delete_p_test_mark');

Route::get('updatePtestmark/{student_id}/{course_code}','PresentationController@update_p_test_mark');

Route::post('editPtestmark/{student_id}/{course_code}','PresentationController@edit_p_test_mark');


Route::get('deletePrename/{id}','PresentationController@deletePresentationname');


//start calss test field

Route::get('/addC_test_mark','ClassTestController@showCname');

Route::view('/addC_test_name','teacher/add_c_test_name');

Route::post('/addccategoryname','ClassTestController@addctname');
Route::post('/addCcategoryname','ClassTestController@addcCtname');

Route::post('/addpCtname','ClassTestController@addCtcname');

Route::get('addctestmark/{id}','ClassTestController@addCtestmark');

Route::post('addCmark','ClassTestController@addCmark');

Route::get('/showC_test_mark','ClassTestController@showClassTestname');

Route::get('showCtestmark/{id}','ClassTestController@show_c_test_mark');

Route::get('deleteCtestmark/{student_id}/{course_code}','ClassTestController@delete_c_test_mark');

Route::get('updateCtestmark/{student_id}/{course_code}','ClassTestController@update_c_test_mark');

Route::post('editCtestmark/{student_id}/{course_code}','ClassTestController@edit_c_test_mark');
Route::get('deleteClassname/{id}','ClassTestController@deleteClassname');
//End class test field
//Total Mark

Route::get('/test','TotalMarkController@test');
Route::get('/testtry','TotalMarkController@testtry');

Route::get('/showtotalcode','TotalMarkController@getCode');
Route::get('/showTotalMark/{course_code}','TotalMarkController@showtotalmark');

